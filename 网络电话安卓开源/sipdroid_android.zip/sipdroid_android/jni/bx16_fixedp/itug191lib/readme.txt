Copy:
1. basop32.c
2. basop32.h
from ITU-T G.191 (09/05) STL basic operator library and put the files in this directory.

It can be downloaded from ITU-T at http://www.itu.int/rec/dologin_pub.asp?lang=e&id=T-REC-G.191-200509-I!!SOFT-ZST-E&type=items
The files are located in ./Software/stl2005/basop

If you encounter any problem downloading the ITU-T files, please send an email to broadvoice@broadcom.com

If you have already downloaded these files for BroadVoice32 then they can simply be copied from there.