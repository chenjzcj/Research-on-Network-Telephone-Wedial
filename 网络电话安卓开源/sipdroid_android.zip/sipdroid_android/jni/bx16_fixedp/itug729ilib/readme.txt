Copy:
1. oper_32b.c
2. oper_32b.h
from ITU-T G.729I (01/07) and put the files in this directory.

It can be downloaded from ITU-T at http://www.itu.int/rec/T-REC-G.729/recommendation.asp?lang=en&parent=T-REC-G.729-200701-I
The files are located in ./Soft/g729AnnexI/c_code

If you encounter any problem downloading the ITU-T files, please send an email to broadvoice@broadcom.com

If you have already downloaded these files for BroadVoice32 then they can simply be copied from there.