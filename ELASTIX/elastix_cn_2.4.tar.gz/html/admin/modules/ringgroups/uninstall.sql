
DROP TABLE IF EXISTS ringgroups;
