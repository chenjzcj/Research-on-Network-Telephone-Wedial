DROP TABLE IF EXISTS `phpagiconf`;
