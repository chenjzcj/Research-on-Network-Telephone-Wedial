DROP TABLE `inventorydb`;
