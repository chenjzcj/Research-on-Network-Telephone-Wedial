DROP TABLE IF EXISTS `timegroups_groups`;
DROP TABLE IF EXISTS `timegroups_detail`;
DROP TABLE IF EXISTS `timeconditions`;
