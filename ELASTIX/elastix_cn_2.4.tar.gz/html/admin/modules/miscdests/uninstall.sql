DROP TABLE IF EXISTS `miscdests`;
