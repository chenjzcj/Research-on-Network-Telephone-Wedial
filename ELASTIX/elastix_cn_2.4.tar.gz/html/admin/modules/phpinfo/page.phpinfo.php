</div>
<div class="content">
<br><br>
<?php
	phpinfo();
?>
</div>
