DROP TABLE gabcast;
